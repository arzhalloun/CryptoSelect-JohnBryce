# CryptoNite
My 2nd project for John Bryce FullStack class using HTML, CSS3, JAVASCRIPT, JQUERY, AJAX, REST API & BOOTSTRAP. 

Some of the features that can be found in CryptoNite include:  
- Coin of interest selection by toggle switch. 
- Expandable information per coin on the homepage. 
- Search Capabilities. 
-  API used for information retrieval: 
- https://www.coingecko.com/api 
  
